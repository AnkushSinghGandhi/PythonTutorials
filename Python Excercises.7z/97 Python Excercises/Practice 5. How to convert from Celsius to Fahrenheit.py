x = int(input("Insert a value in Celcius: "))

x = round(x*(9/5) + 32 )
print(str(x) + 'F')