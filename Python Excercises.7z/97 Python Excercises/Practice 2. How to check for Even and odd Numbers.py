x = int(input("Insert any number: "))

if x%2 == 0:
    print("This is an EVEN number!")
else:
    print("This is an ODD number!")