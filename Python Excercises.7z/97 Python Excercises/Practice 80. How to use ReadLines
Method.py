fp = open("C:/Users/USER/Desktop/Python Projects/Python_File/Python.txt")
data = fp.readlines()
fp.close()

print(data)