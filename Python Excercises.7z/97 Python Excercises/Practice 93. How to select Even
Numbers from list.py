dict = {'one':1, 'two':2, 'three':3}

x = [[y,z]for y, z in dict.items()]

print(x)
