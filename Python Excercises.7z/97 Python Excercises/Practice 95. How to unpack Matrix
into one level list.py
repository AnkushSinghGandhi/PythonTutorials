x = [i.strip() for i in open("C:/Users/USER/Desktop/Python Projects/Python_File/Python.txt")]
print(x)