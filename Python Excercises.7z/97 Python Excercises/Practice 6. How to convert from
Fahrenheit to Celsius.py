x = int(input("Insert a Fehrenheit value: "))

x = round((x-32)*(5/9))
print(str(x)+'C')