yr = int(input("Insert any year to check for leap year: "))

if yr%4 == 0:
    print("This is a leap year!")
else:
    print("This is not a leap year!")