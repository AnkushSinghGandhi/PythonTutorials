x = float(input("Insert any number: "))

if x>0:
    print("This is a POSITIVE number")
elif x < 0:
    print("This is a NEGATIVE number")
else:
    print("The number is ZERO")