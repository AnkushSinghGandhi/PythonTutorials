x = [[1,2,3],[4,5,6],[7,8,9]]

y = [item for row in x for item in row]

print(y)