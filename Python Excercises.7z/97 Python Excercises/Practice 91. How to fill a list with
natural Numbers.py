x = int(input("Insert range of natural numbers: "))
num = [y+1 for y in range(x)]
print(num)